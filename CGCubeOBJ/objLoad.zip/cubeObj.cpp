#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>

#include <GL/glew.h>
#include <GL/glut.h>
#include<glm/glm.hpp>
#include<glm/gtx/transform.hpp>
#include<glm/gtc/quaternion.hpp>
#include<glm/gtx/quaternion.hpp>

#define MAXNUM 1024

using namespace std;

GLuint cubeVAO[1];
GLuint cubeVBO[2];
GLuint cubeVEO[2];

GLuint pigVAO[1];
GLuint pigVBO[2];
GLuint pigVEO[2];

GLuint  g_matLoc;
GLuint g_programID;
GLuint g_colorID;
vector<GLfloat> cube_vtx;
vector<GLuint>cube_index;
vector <string> cube_index_list;
   
vector<GLfloat>pig_vtx;
vector<GLfloat> pig_vt;
vector<GLuint>pig_index;
vector<GLint> pig_normal;
//vector<char*> index_list;
vector <string> index_list;

GLfloat g_screenW, g_screenH;

GLfloat transMat[16];
glm::mat4 rot;
bool rotateMode;
bool projectMode;
int shapeMode;//1:ť�� , 2: ����.

float angle;
float camCenterZ;
float camCenterX;
float camCenterY;
float camPan;
float camTilt;

GLfloat ambiCol[3], diffCol[3], specCol[3];

GLuint LoadShaders(const char* vertex_file_path, const char* fragment_file_path)
{
	//create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	GLint Result = GL_FALSE;
	int InfoLogLength;

	//Read the vertex shader code from the file
	string VertexShaderCode;
	ifstream VertexShaderStream(vertex_file_path, ios::in);
	if (VertexShaderStream.is_open())
	{
		string Line = "";
		while (getline(VertexShaderStream, Line))
			VertexShaderCode += "\n" + Line;
		VertexShaderStream.close();
	}

	//Compile Vertex Shader
	printf("Compiling shader : %s\n", vertex_file_path);
	char const* VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
	glCompileShader(VertexShaderID);

	//Check Vertex Shader
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	vector<char> VertexShaderErrorMessage(InfoLogLength);
	glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
	fprintf(stdout, "%s\n", &VertexShaderErrorMessage[0]);

	//Read the fragment shader code from the file
	string FragmentShaderCode;
	ifstream FragmentShaderStream(fragment_file_path, ios::in);
	if (FragmentShaderStream.is_open())
	{
		string Line = "";
		while (getline(FragmentShaderStream, Line))
			FragmentShaderCode += "\n" + Line;
		FragmentShaderStream.close();
	}

	//Compile Fragment Shader
	printf("Compiling shader : %s\n", fragment_file_path);
	char const* FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
	glCompileShader(FragmentShaderID);

	//Check Fragment Shader
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	vector<char> FragmentShaderErrorMessage(InfoLogLength);
	glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
	fprintf(stdout, "%s\n", &FragmentShaderErrorMessage[0]);

	//Link the program
	fprintf(stdout, "Linking program\n");
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);

	// Check the program
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	vector<char> ProgramErrorMessage(InfoLogLength);
	glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
	fprintf(stdout, "%s\n", &ProgramErrorMessage[0]);

	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	return ProgramID;
}

void renderScene(void)
{
	//Clear all pixels
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//Let's draw something here
	glm::mat4 projMat;
	if (projectMode)
		projMat = glm::perspective(45.0f, 70.0f / 48.0f, 0.1f, 100.0f);
	else
		projMat = glm::ortho(1.0f, 0.0f, 0.0f, 0.0f, 2.0f, 100.0f);

	glm::mat4 viewMat = glm::mat4(1.0f);
	viewMat[3] = glm::vec4(-camCenterX, -camCenterY, -camCenterZ, 1.0f);
	glm::mat4 panMat = glm::rotate(-camPan, glm::vec3(0, 1, 0));
	glm::mat4 tiltMat = glm::rotate(-camTilt, glm::vec3(0, 0, 1));
	viewMat = tiltMat*panMat*viewMat;

	GLuint viewLoc = glGetUniformLocation(g_programID, "viewMat");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &viewMat[0][0]);

	GLuint projLoc = glGetUniformLocation(g_programID, "projMat");
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, &projMat[0][0]);

	glm::mat4 worldMat = glm::mat4(0.1f);
	 
	glm::mat4 rotMat = glm::rotate(angle, glm::vec3(0, 1, 0));

	worldMat = worldMat*rotMat;

	GLuint matLoc = glGetUniformLocation(g_programID, "tranMat");
	glUniformMatrix4fv(matLoc, 1, GL_FALSE, &worldMat[0][0]);

	if (shapeMode == 1)
	{
		glBindVertexArray(cubeVAO[0]);
		glVertexAttrib3f(g_colorID, 0.0, 0.5, 0.9);
		/*for (int idxTri = 0; idxTri < cube_index.size() / 3; idxTri++)
		{
			glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, ((GLvoid*)(sizeof(int)*idxTri*3)));
		}*/
		glDrawElements(GL_TRIANGLES, cube_index.size(), GL_UNSIGNED_INT, ((GLvoid*)(0)));
	}
	else if (shapeMode == 2)
	{
		glBindVertexArray(pigVAO[0]);
		glVertexAttrib3f(g_colorID, 0.0, 0.5, 0.9);
		glDrawElements(GL_LINES, pig_index.size(), GL_UNSIGNED_INT, ((GLvoid*)(0)));
	}
	glutSwapBuffers();
}
//�ʱ�ȭ. ���⼭�� �ٲܰ��� �����ϴ�.
void init()
{
	//initilize the glew and check the errors.
	GLenum res = glewInit();
	if (res != GLEW_OK)
	{
		fprintf(stderr, "Error: '%s' \n", glewGetErrorString(res));
	}

	//select the background color
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glEnable(GL_VERTEX_PROGRAM_POINT_SIZE);
	glEnable(GL_DEPTH_TEST);

	angle = 0.0;
	projectMode = true;
	camCenterZ = 10;
	camPan = 0.0;
	camTilt = 0.0;

	shapeMode = 1;
}
void myMouse(int button, int state, int x, int y)
{
	float fx, fy;
	fx = (x / (float)480) * 2  ;
	fy = (y / (float)480) * 2  ;

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{

	}
	else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		projectMode != projectMode;
	}
	glutPostRedisplay();
}
void myKeyboard(unsigned char key, int x, int y)
{
	if (key == 'a')
	{
		angle += 0.1;
	}
	else if (key == 'q')
		camCenterZ += 0.1;
	else if (key == 'w')
		camCenterZ -= 0.1;
	else if (key == 'e')
		camCenterX += 0.1;
	else if (key == 'r')
		camCenterX -= 0.1;
	else if (key == 't')
		camCenterY += 0.1;
	else if (key == 'y')
		camCenterY -= 0.1;

	else if (key == 'z')
		camPan += 0.1;
	else if (key == 'x')
		camPan -= 0.1;

	else if (key == 'c')
		camTilt += 0.1;
	else if (key == 'v')
		camTilt -= 0.1;

	else if (key == 'm')
		projectMode != projectMode;
	else if (key == '1')
		shapeMode = 1;
	else if (key == '2')
		shapeMode = 2;

	glutPostRedisplay();
}

//mtl ���� ������ �޴� �Լ�. ���� �Ⱦ�.
int useMtl(char* filename)
{
	ifstream mtlOpen(filename);
	while (!mtlOpen.eof())
	{
		char line[MAXNUM];
		mtlOpen.getline(line, MAXNUM);
		char* context;
		strtok_s(line, " ", &context);
		if (context == "ka")
		{
			//�����Ʈ ��.
			int n=0;
			for (;;)
			{
				char* temp = strtok_s(context, " ", &context);
				if (temp != NULL)
				{
					float a = atof(temp);
					ambiCol[n++] = a;
				}
				else
					break;
			}
		}
		else if (context == "kd")
		{
			//��ǻ���
			int n = 0;
			for (;;)
			{
				char* temp = strtok_s(context, " ", &context);
				if (temp != NULL)
				{
					float a = atof(temp);
					diffCol[n++] = a;
				}
				else
					break;
			}
		}
		else if (context == "ks")
		{
			//����ŧ����
			int n = 0;
			for (;;)
			{
				char* temp = strtok_s(context, " ", &context);
				if (temp != NULL)
				{
					float a = atof(temp);
					specCol[n++] = a;
				}
				else
					break;
			}
		}
		/*else if ()
		{

		}*/
	}

	return 0;
}

//�Ѵ� �Ǵ°� ������..
int getEveryVtx(string fileName, vector<GLfloat>& p_vtx, vector<GLfloat>& p_vt, vector<GLuint>& p_index, vector<string>& index_list ){
	ifstream fileObjOpen(fileName);
	vector<GLuint> index;
	int indexNum = 0;
	while (!fileObjOpen.eof())
	{
		char line[MAXNUM];
		fileObjOpen.getline(line, MAXNUM);
		char* context;
		char* first = strtok_s(line, " ", &context);
		int vtxCount = 0;
		int groupNum = 0;
		if (first == NULL)
		{
			continue;
		}
		if (!strncmp(first, "vt", 2))
		{
			for (;;)
			{
				char* temp = strtok_s(context, " ", &context);
				if (temp != NULL)
				{
					float vtx = atof(temp);
					p_vt.push_back(vtx);
				}
				else
					break;
			}
		}
		else if (!strncmp(first, "v", 1))
		{
			vtxCount++;
			for (;;)
			{
				char* temp = strtok_s(context, " ", &context);
				if (temp != NULL)
				{
					float vtx = atof(temp);
					p_vtx.push_back(vtx);
				}
				else
					break;
			}
		}
		else if (!strncmp(first, "f", 1))
		{
			vector<GLuint> index_temp;
			for (;;)
			{
				char* copy = strtok_s(context, " ", &context);
				if (copy == NULL)
				{
					break;
				}
				else
				{
					bool being = false;
					for (int i = 0; i < index_list.size(); i++)
					{
						if (index_list[i] == string(copy))
						{
							being = true;
							index.push_back(i);
							index_temp.push_back(i);
							break;
						}
					}
					if (!being)
					{
						index_list.push_back(string(copy));
						index.push_back(indexNum);
						index_temp.push_back(indexNum);
						indexNum++;
					}
				}
			}
			p_index.push_back(index_temp[0]);
			p_index.push_back(index_temp[1]);
			p_index.push_back(index_temp[2]);
			p_index.push_back(index_temp[0]);
			p_index.push_back(index_temp[2]);
			p_index.push_back(index_temp[3]);
		}
		else if (!strncmp(first, "mtllib", 6))
		{
			/*���밡������.*/
		}
		else if (!strncmp(first, "usemtl", 6) || !strncmp(first, "s", 1))
		{
			int a = 1;
		}
	}
	return p_vtx.size() / 3;
}
//vertex�� ������ ��ü�� ���ۿ� ����.
int createShape(GLuint &vao, GLuint &vbo, GLuint &veo, vector<string> index_list, vector<GLfloat> p_vtx, vector<GLuint> p_index, vector<GLfloat> p_vt)
{
	vector<GLfloat> vtx;
	vector<GLuint> index;
	vector<GLfloat> normal;
	for (int i = 0; i < index_list.size(); i++)
	{
		char temp[1024];
		strcpy_s(temp, 1024, index_list[i].data());
		char* tex;
		char* cut = strtok_s(temp, "/", &tex);
		int idx = atoi(cut);
		index.push_back(idx);

		int texture = atoi(tex);
		vtx.push_back(p_vtx[(idx - 1) * 3]);
		vtx.push_back(p_vtx[(idx - 1) * 3 + 1]);
		vtx.push_back(p_vtx[(idx - 1) * 3 + 2]);
		if (texture <= 0)
		{
	/*		vtx.push_back(0);
			vtx.push_back(0);*/
		}
		else
		{
			vtx.push_back(p_vt[(texture - 1) * 2]);
			vtx.push_back(p_vt[(texture - 1) * 2 + 1]);
		}
	}
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*vtx.size(),vtx.data(), GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, veo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint)*p_index.size(), p_index.data(), GL_STATIC_DRAW);

	return 0;
}
int main(int argc, char **argv)
{
	//init GLUT and create Window
	//initialize the GLUT
	glutInit(&argc, argv);
	//GLUT_DOUBLE enables double buffering (drawing to a background buffer while the other buffer is displayed)
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	//These two functions are used to define the position and size of the window. 
	glutInitWindowPosition(200, 200);
	glutInitWindowSize(700, 480);

	g_screenW = 700;
	g_screenH = 480;
	//This is used to define the name of the window.
	glutCreateWindow("Simple OpenGL Window");

	//call initization function
	init();	

	//ť�� ��ǥ�� �ޱ�
	//getCubeVtx();
	vector<GLfloat> cube_vt;
	getEveryVtx(string("cube.obj"), cube_vtx, cube_vt, cube_index, cube_index_list);
	////���������� ��ǥ���ޱ�
	//getPigVtx();
	getEveryVtx(string("PiggyBank.obj"), pig_vtx, pig_vt, pig_index, index_list);

	GLuint programID = LoadShaders("VertexShader.txt", "FragmentShader.txt");
	glUseProgram(programID);
	g_programID = programID;

	GLint posID = glGetAttribLocation(g_programID, "pos");
	g_colorID = glGetAttribLocation(g_programID, "col");

	glGenVertexArrays(1, cubeVAO);
	glGenBuffers(2, cubeVBO);
	glGenBuffers(2, cubeVEO); 

	//bind cube
	glBindVertexArray(cubeVAO[0]);
	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO[0]);
	glVertexAttribPointer(posID, 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 3, ((GLvoid*)(0)));
	glEnableVertexAttribArray(posID);

	//gen pig
	glGenVertexArrays(1, pigVAO);
	glGenBuffers(1, pigVBO);
	glGenBuffers(1, pigVEO);
	//bind pig	
	glBindVertexArray(pigVAO[0]);
	glBindBuffer(GL_ARRAY_BUFFER, pigVBO[0]);
	glVertexAttribPointer(posID, 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, ((GLvoid*)(0)));
	glEnableVertexAttribArray(posID);
	
	/*createCube(cubeVAO[0], cubeVBO[0], cubeVEO[0]);
	createPig(pigVAO[0], pigVBO[0], pigVEO[0]);*/
	createShape(cubeVAO[0], cubeVBO[0], cubeVEO[0],cube_index_list,cube_vtx,cube_index,cube_vt);
	createShape(pigVAO[0], pigVBO[0], pigVEO[0],index_list,pig_vtx,pig_index,pig_vt);

	glutMouseFunc(myMouse);
	glutKeyboardFunc(myKeyboard);
	glutDisplayFunc(renderScene);

	//enter GLUT event processing cycle
	glutMainLoop();
	return 1;
}